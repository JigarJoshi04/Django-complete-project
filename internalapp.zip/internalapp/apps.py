from django.apps import AppConfig


class InternalappConfig(AppConfig):
    name = 'internalapp'
